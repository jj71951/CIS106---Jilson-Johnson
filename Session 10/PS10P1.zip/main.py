# Function to compute next month's forecast
def compute_forecast(month, sales):
    # Dictionary to map months to forecast percent
    forecast_percent = {
        "Jan": 0.10, "Feb": 0.10, "Mar": 0.10,
        "Apr": 0.15, "May": 0.15, "Jun": 0.15,
        "Jul": 0.20, "Aug": 0.20, "Sep": 0.20,
        "Oct": 0.25, "Nov": 0.25, "Dec": 0.25
    }

    # Determine forecast percent based on the month
    forecast = forecast_percent.get(month, 0)

    # Compute next month's sales
    next_month_sales = sales * (1 + forecast)

    return next_month_sales

# Main program
while True:
    # Prompt the user to continue or stop the program
    response = input("Do you want to continue? (Yes/No): ")
    if response.lower() != 'yes':
        break

    # Input last name, month, and sales
    last_name = input("Enter last name: ")
    month = input("Enter month: ")
    sales = float(input("Enter sales: "))

    # Compute next month's forecast
    next_month_sales = compute_forecast(month, sales)

    # Display next month's sales
    print(f"Next month's sales forecast for {last_name}:", next_month_sales)
