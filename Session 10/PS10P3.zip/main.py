# Function to compute the out the door price
def compute_out_the_door_price(msrp, make, model, ev_code):
    # Dictionary to map models to discount percent
    discount_percent = {
        "Honda Accord": 0.10,
        "Toyota Rav4": 0.15,
        "Electric Vehicle": 0.30
    }

    # Determine discount percent based on make and model
    if make == "Electric":
        discount = discount_percent.get("Electric Vehicle", 0.05)
    else:
        discount = discount_percent.get(model, 0.05)

    # Compute new MSRP after discount
    new_msrp = msrp * (1 - discount)

    # Compute total out the door price with 7% sales tax
    total = new_msrp * 1.07

    return total

# Main program
while True:
    # Prompt the user to continue or stop the program
    response = input("Do you want to continue? (Yes/No): ")
    if response.lower() != 'yes':
        break

    # Input make, model, electric vehicle code, and MSRP
    make = input("Enter make of the automobile: ")
    model = input("Enter model of the automobile: ")
    ev_code = input("Is it an electric vehicle? (Y/N): ")
    msrp = float(input("Enter MSRP (sticker price) of the automobile: "))

    # Compute out the door price
    out_the_door_price = compute_out_the_door_price(msrp, make, model, ev_code)

    # Display total out the door price
    print(f"Out the door price for {make} {model}: ${out_the_door_price:.2f}")
