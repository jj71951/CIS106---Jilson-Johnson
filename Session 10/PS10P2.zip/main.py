# Function to compute square footage of the room and gallons of paint needed
def compute_paint_gallons(length, width, height):
    # Compute square footage of the room
    square_footage = (2 * length * width) + (2 * length * height) + (2 * width * height)

    # Compute number of gallons needed
    gallons_needed = square_footage / 50

    return gallons_needed

# Main program
while True:
    # Prompt the user to continue or stop the program
    response = input("Do you want to continue? (Yes/No): ")
    if response.lower() != 'yes':
        break

    # Input length, width, and height of the room
    length = float(input("Enter length of the room (in feet): "))
    width = float(input("Enter width of the room (in feet): "))
    height = float(input("Enter height of the room (in feet): "))

    # Compute gallons of paint needed
    gallons_needed = compute_paint_gallons(length, width, height)

    # Display number of gallons needed
    print(f"Number of gallons needed to paint the room: {gallons_needed:.2f}")
