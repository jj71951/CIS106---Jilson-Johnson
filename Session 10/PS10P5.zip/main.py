# Function to compute the assessed value
def compute_assessed_value(county, market_value):
    # Dictionary to map counties to assessed value percent
    assessed_value_percent = {
        "Cook": 0.90,
        "DuPage": 0.80,
        "McHenry": 0.75,
        "Kane": 0.60
    }

    # Determine assessed value percent based on the county
    assessed_percent = assessed_value_percent.get(county, 0.70)

    # Compute assessed value
    assessed_value = market_value * assessed_percent

    return assessed_value

# Main program
total_market_value = 0
total_assessed_value = 0

while True:
    # Prompt the user to continue or stop the program
    response = input("Do you want to continue? (Yes/No): ")
    if response.lower() != 'yes':
        break

    # Input county and market value
    county = input("Enter county: ")
    market_value = float(input("Enter market value of the home: "))

    # Compute assessed value
    assessed_value = compute_assessed_value(county, market_value)

    # Add market value and assessed value to totals
    total_market_value += market_value
    total_assessed_value += assessed_value

    # Display assessed value
    print(f"Assessed value for {county}: ${assessed_value:.2f}")

# Display total market value and assessed value
print(f"Total market value of all homes: ${total_market_value:.2f}")
print(f"Total assessed value of all homes: ${total_assessed_value:.2f}")
