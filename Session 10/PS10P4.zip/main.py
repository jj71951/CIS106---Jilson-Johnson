# Function to compute the train ticket price
def compute_ticket_price(miles):
    if miles >= 30:
        ticket_price = 12
    elif 20 <= miles <= 29:
        ticket_price = 10
    elif 10 <= miles <= 19:
        ticket_price = 8
    else:
        ticket_price = 5
    return ticket_price

# Main program
total_ticket_price = 0

while True:
    # Prompt the user to continue or stop the program
    response = input("Do you want to continue? (Yes/No): ")
    if response.lower() != 'yes':
        break

    # Input last name and miles from downtown Chicago
    last_name = input("Enter last name: ")
    miles = int(input("Enter miles from downtown Chicago: "))

    # Compute ticket price
    ticket_price = compute_ticket_price(miles)

    # Add ticket price to total
    total_ticket_price += ticket_price

    # Display ticket price
    print(f"Ticket price for {last_name}: ${ticket_price}")

# Display total price of all tickets
print(f"Total price of all tickets: ${total_ticket_price}")
