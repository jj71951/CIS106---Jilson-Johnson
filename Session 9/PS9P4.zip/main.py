def determine_pay_rate(job_code):
  if job_code == 'L':
      return 25.00
  elif job_code == 'A':
      return 30.00
  elif job_code == 'J':
      return 50.00
  else:
      return 0.00

total_gross_pay = 0

try:
  while True:
      # Input employee details
      last_name = input("Enter employee's last name: ")
      job_code = input("Enter job code (L, A, or J): ")
      hours_worked = float(input("Enter hours worked: "))

      # Determine pay rate using function
      pay_rate = determine_pay_rate(job_code)

      # Calculate gross pay
      if hours_worked <= 40:
          gross_pay = hours_worked * pay_rate
      else:
          regular_pay = 40 * pay_rate
          overtime_pay = (hours_worked - 40) * 1.5 * pay_rate
          gross_pay = regular_pay + overtime_pay

      # Display last name and gross pay
      print("Last Name:", last_name)
      print("Gross Pay:", gross_pay)

      # Add gross pay to total gross pay
      total_gross_pay += gross_pay

except EOFError:
  # Display total gross pay
  print("Total Gross Pay:", total_gross_pay)
