def compute_total(quantity, price):
    total = quantity * price
    # Apply 10% discount if total is over $10,000
    if total > 10000.00:
        total *= 0.9
    return total

# Initialize variables
extended_price_sum = 0

try:
    while True:
        # Input quantity and price
        quantity = int(input("Enter quantity: "))
        price = float(input("Enter price: "))

        # Calculate total using function
        total = compute_total(quantity, price)

        # Display quantity, price, and total
        print("Quantity:", quantity)
        print("Price:", price)
        print("Total:", total)

        # Add total to extended price sum
        extended_price_sum += total

except EOFError:
# Display sum of extended prices
  print("Sum of Extended Prices:", extended_price_sum)
