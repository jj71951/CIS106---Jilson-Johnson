def compute_batting_average(hits, at_bats):
  batting_average = hits / at_bats if at_bats != 0 else 0
  return batting_average

player_count = 0

try:
  while True:
      # Input player details
      last_name = input("Enter player's last name: ")
      hits = int(input("Enter number of hits: "))
      at_bats = int(input("Enter number of at bats: "))

      # Calculate batting average using function
      batting_average = compute_batting_average(hits, at_bats)

      # Display last name and batting average
      print("Last Name:", last_name)
      print("Batting Average:", batting_average)

      # Increment player count
      player_count += 1

except EOFError:
  # Display total number of players entered
  print("Total Players:", player_count)
