def compute_miles_per_gallon(miles, gallons):
  miles_per_gallon = miles / gallons if gallons != 0 else 0
  return miles_per_gallon

trip_count = 0

try:
  while True:
      # Input trip details
      destination_city = input("Enter destination city: ")
      miles_travelled = float(input("Enter miles travelled: "))
      gallons_used = float(input("Enter gallons used: "))

      # Calculate miles per gallon using function
      miles_per_gallon = compute_miles_per_gallon(miles_travelled, gallons_used)

      # Display destination city, miles, and miles per gallon
      print("Destination City:", destination_city)
      print("Miles:", miles_travelled)
      print("Miles per Gallon:", miles_per_gallon)

      # Increment trip count
      trip_count += 1

except EOFError:
  # Display total number of trips made
  print("Total Trips:", trip_count)
