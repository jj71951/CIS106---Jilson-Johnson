def compute_tuition(credit_hours, district_code):
  if district_code == 'I':
      return credit_hours * 250
  elif district_code == 'O':
      return credit_hours * 550
  else:
      return 0.00

total_tuition_owed = 0

try:
  while True:
      # Input student details
      last_name = input("Enter student's last name: ")
      credit_hours = int(input("Enter credit hours: "))
      district_code = input("Enter district code (I or O): ")

      # Compute tuition owed using function
      tuition_owed = compute_tuition(credit_hours, district_code)

      # Display student name and tuition owed
      print("Student Name:", last_name)
      print("Tuition Owed:", tuition_owed)

      # Add tuition owed to total tuition owed
      total_tuition_owed += tuition_owed

except EOFError:
  # Display total tuition owed
  print("Total Tuition Owed:", total_tuition_owed)
