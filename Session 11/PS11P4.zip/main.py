# Function to compute average score and average score with handicap
def compute_bowler_score(scores, handicap):
    average_score = sum(scores) / len(scores)
    average_score_with_handicap = average_score + handicap
    return average_score, average_score_with_handicap

# Main program
last_name = input("Enter bowler's last name: ")
scores = [float(input(f"Enter score {i+1}: ")) for i in range(3)]
handicap = float(input("Enter handicap: "))

average_score, average_score_with_handicap = compute_bowler_score(scores, handicap)

print(f"Bowler last name: {last_name}")
print(f"Average score: {average_score:.2f}")
print(f"Average score with handicap: {average_score_with_handicap:.2f}")
