# Function to compute total points and average score
def compute_exam_score(scores):
    total_points = sum(scores)
    average_score = total_points / len(scores)
    return total_points, average_score

# Main program
last_name = input("Enter student's last name: ")
scores = [float(input(f"Enter score {i+1}: ")) for i in range(3)]

total_points, average_score = compute_exam_score(scores)

print(f"Student last name: {last_name}")
print(f"Total points: {total_points}")
print(f"Average exam score: {average_score}")
