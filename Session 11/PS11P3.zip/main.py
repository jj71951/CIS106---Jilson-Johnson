# Function to compute commission and next year's target
def compute_sales_report(sales):
    # Use ternary operator to calculate commission
    commission = 0.1 * sales if sales > 100000 else 0.05 * sales
    next_year_target = 0.05 * sales
    return commission, next_year_target

# Main program
salesperson_name = input("Enter salesperson's last name: ")
sales = float(input("Enter sales amount: "))

commission, next_year_target = compute_sales_report(sales)

print(f"Salesperson name: {salesperson_name}")
print(f"Commission: ${commission:.2f}")
print(f"Next year's target: ${next_year_target:.2f}")
