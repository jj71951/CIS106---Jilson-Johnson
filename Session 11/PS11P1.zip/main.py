# Function to compute discount amount and discounted price
def compute_discount(quantity, price, discount_rate):
    discount_amount = quantity * price * discount_rate
    discounted_price = quantity * price - discount_amount
    return discount_amount, discounted_price

# Main program
quantity = int(input("Enter quantity: "))
price = float(input("Enter price per item: "))
discount_rate = float(input("Enter discount rate (as a decimal): "))

discount_amount, discounted_price = compute_discount(quantity, price, discount_rate)

print(f"Quantity: {quantity}")
print(f"Price per item: ${price:.2f}")
print(f"Discount amount: ${discount_amount:.2f}")
print(f"Discounted price: ${discounted_price:.2f}")
