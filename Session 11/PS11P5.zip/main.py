# Global variables for total and tax
total = 0
tax = 0

# Function to compute total and tax
def compute_total_and_tax(quantity, unit_price):
    global total, tax
    total = quantity * unit_price
    tax = 0.07 * total

# Main program
quantity = int(input("Enter quantity: "))
unit_price = float(input("Enter unit price: "))

compute_total_and_tax(quantity, unit_price)

print(f"Total: ${total:.2f}")
print(f"Tax: ${tax:.2f}")
