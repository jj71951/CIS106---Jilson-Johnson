#Input
total_meal_cost = float(input("Enter the total cost of the meal: "))

#Compute tips
tip_percentages = [15, 18, 20]
for tip_percentage in tip_percentages:
    tip = total_meal_cost * (tip_percentage / 100)
    total_with_tip = total_meal_cost + tip
    print(f"With {tip_percentage}% Tip:")
    print("Total:                 ", total_meal_cost)
    print("Tip:                    ", round (tip, 2))
    print("Total with Tip:   ", round(total_with_tip, 2))
    print()
  