# Allow the user to enter exam scores
exam1_score = float(input("Enter the score for the first time: "))
exam2_score = float(input("Enter the score for the second time: "))

# Calculate total score
total_score = (exam1_score * 0.6) + (exam2_score * 0.4)

# Display the total score
print("The total score is:", total_score)

