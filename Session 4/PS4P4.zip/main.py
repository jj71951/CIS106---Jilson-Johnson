#Input
first_name = input("Enter your first name: ")
steps_walked = int(input("Enter the number of steps you walked today: "))

#Calculate calories burned
calories_burned = steps_walked * 0.25

#Display result
print("Name:", first_name)
print("Calories Burned:", calories_burned)