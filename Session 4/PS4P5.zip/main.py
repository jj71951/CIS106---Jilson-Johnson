# Input
fixed_costs = float(input("Enter the fixed costs: "))
price_per_unit = float(input("Enter price per unit: "))
cost_per_unit = float(input("Enter cost per unit: "))

# Calculate break even point
break_even_point = fixed_costs / (price_per_unit - cost_per_unit)

#Display result
print("Break Even Point: ", break_even_point)