#Input
purchase_price = float(input("Enter the purchase price : "))
current_price = float(input("Enter the current price : "))
quantity = int(input("Enter the quantity : "))

#Calculate value increase/decrease
value_change = (current_price - purchase_price) * quantity

#Display result
print("The value change is : ", value_change)