class Student:
  def __init__(self, first_name, last_name, district_code, enrolled_credits):
      self.first_name = first_name
      self.last_name = last_name
      self.district_code = district_code
      self.enrolled_credits = enrolled_credits

  def compute_tuition(self):
      cost_per_credit = 250.0 if self.district_code == 'I' else 500.0

      tuition_owed = self.enrolled_credits * cost_per_credit
      return tuition_owed

# Testing the Student class
student1 = Student("Alice", "Smith", "I", 12)
tuition_owed = student1.compute_tuition()
print(f"{student1.first_name} {student1.last_name} owes ${tuition_owed} in tuition.")
