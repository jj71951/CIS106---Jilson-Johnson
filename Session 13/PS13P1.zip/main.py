class Employee:
  def __init__(self, name, salary):
      self.name = name
      self.salary = salary

  def calculate_bonus(self, bonus_rate):
      bonus = self.salary * bonus_rate
      return bonus

# Testing the Employee class
employee1 = Employee("John", 50000)
bonus_rate = float(input("Enter the bonus rate: "))
bonus = employee1.calculate_bonus(bonus_rate)
print(f"The bonus for {employee1.name} is: ${bonus}")
