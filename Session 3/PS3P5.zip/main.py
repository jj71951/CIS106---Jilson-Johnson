#constants
PIE = 3.174

#input
radius = float(input("Enter the radius of the circle: "))

#process
area = PIE * radius ** 2
perimeter = 2 * PIE * radius

#output
print("The area of the circle is: ", area)
print("Perimeter of the circle is: ", perimeter)