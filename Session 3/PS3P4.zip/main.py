#input
make = input("Enter the make of the auto: ")
model = input("Enter the model of the auto: ")
msrp = float(input("Enter the MSRP of the auto: "))
discount_percent = float(input("Enter the discount percent (in decimal form): "))

#process
amount_off = msrp * discount_percent
discounted_price = msrp - amount_off

#output
print("Make: ", make)
print("Model: ", model)
print("MSRP: ", msrp)
print("Discount Percent: ", discount_percent)
print("Amount Off: ", amount_off)
print("Discounted Price: ", discounted_price)