#input
ticker_symbol = input("Enter the stock ticker symbol: ")
number_of_shares = float("Enter the number of shares: ")
cost_per_share = float(input("Enter the cost per share: $"))

#process
amount_invested = number_of_shares * cost_per_share

#output
print("Stock Ticker Symbol: ", ticker_symbol)
print("Amount Invested: $", amount_invested)