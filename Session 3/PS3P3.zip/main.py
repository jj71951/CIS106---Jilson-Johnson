#input
amount_recieved = float(input("Enter the amount recieved: $"))

#process
each_share = amount_recieved / 3

#output
print("Each person will recieve: $", each_share)