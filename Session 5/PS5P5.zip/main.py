# Input
last_name = input("Enter your last name: ")
num_dependents = int(input("Enter the number of dependents: "))
gross_income = float(input("Enter the gross income: "))

#Compute adjusted gross income
adjusted_gross_income = gross_income - (num_dependents * 12000)

# Determine tax rate using ternary operator
tax_rate = 0.2 if adjusted_gross_income > 50000 else 0.1

# Compute taxable income
income_tax = adjusted_gross_income * tax_rate

#Check if income tax is negative and set to $10 if it is
if income_tax < 0:
    income_tax = 10

#Display results
print("Last Name:", last_name)
print("Gross Income: $", gross_income)
print("Number of Dependents:", num_dependents)
print("Adjusted Gross Income: $", adjusted_gross_income)
print("Income Tax: $", income_tax)
