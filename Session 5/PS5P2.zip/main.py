#Input
item = input("Enter the item (A or B): ")
quantity = float(input("Enter the quantity: "))

#Determine unit price based on item
unit_price = 10.0 if item == "A" else 20.0

#Calculate extended price
extended_price = quantity * unit_price

#Display results
print("Item:", item)
print("Quantity:", quantity)
print("Extended Price:", extended_price)
