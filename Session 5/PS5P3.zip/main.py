#Input
num_books = int(input("Enter the number of books purchased: "))
cost_per_book = float(input("Enter the cost per book: "))

#Compute order total
order_total = num_books * cost_per_book

#Determine shipping charge
shipping_charge = 0.0 if order_total > 50.0 else 25.0

#Display results
print("Order total: $", order_total)
print("Shipping charge: $", shipping_charge)