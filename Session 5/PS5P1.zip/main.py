#Input
quantity = int(input("Enter the quantity of the item: "))

#Determine unit price based on quantity
unit_price = 3.00 if quantity >= 1000 else 5.00

#Calculate extended price
extended_price = quantity * unit_price

#Calculate tax
tax = 0.07 * extended_price

#Calculate total
total = extended_price + tax

#Display results
print("Quantity:", quantity)
print("Unit Price: $", unit_price)
print("Extended Price: $", extended_price)
print("Tax: $", tax)
print("Total: $", total)