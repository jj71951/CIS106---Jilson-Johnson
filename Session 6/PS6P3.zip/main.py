#Input
principle_amount = float(input("Enter the principle amount of the CD: "))
years_to_maturity = int(input("Enter the number of years until maturity: "))

#Determine interest rate based on principle amount and maturity
if principle_amount > 100000.00 and years_to_maturity == 5:
    interest_rate = 0.06
elif 50000.00 <= principle_amount <= 100000.00 and years_to_maturity == 10:
    interest_rate = 0.05
else:
    interest_rate = 0.04

#Calculate first year interest 
first_year_interest = principle_amount * interest_rate

#Display results
print("Principle Amount: $", principle_amount)
print("Interest Rate: ", interest_rate)
print("First Year Interest: $", first_year_interest)