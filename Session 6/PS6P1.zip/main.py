#Input
quantity = int(input("Enter the quantity of widgets: "))

#Determine price based on quantity
if quantity > 1000:
    price_per_widget = 10
elif quantity >= 500 and quantity <= 1000:
    price_per_widget = 20
else: 
    price_per_widget = 30

#Calculate extended price
extended_price = quantity * price_per_widget

#Calculate tax
tax_rate = 0.07
tax_amount = extended_price + tax_rate

#Calculate total
total = extended_price + tax_amount

#Display results
print("Extended price: $", extended_price)
print("Tax amount: $", tax_amount)
print("Total: $", total)