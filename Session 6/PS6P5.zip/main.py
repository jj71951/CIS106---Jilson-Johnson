#Input
last_name = input("Enter the emoloyee's last name: ")
salary = float(input("Enter the employee's salary: "))
job_level = int(input("Enter the employee's job level: "))

#Determine the bonus based on the job level
if job_level >= 10:
    bonus_rate = 0.25
elif 5 <= job_level <= 9:
    bonus_rate = 0.2
else:
  bonus_rate = 0.10

#Compute bonus
bonus = salary * bonus_rate

#Display the rate
print("Employee's Last Name:", last_name)
print("Bonus: $", bonus)