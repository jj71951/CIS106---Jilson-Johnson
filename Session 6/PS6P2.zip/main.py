#Input
part_number = int(input("Enter the part number: "))
quantity = int(input("Enter the quantity: "))

#Determine cost per unit based on part number
if part_number == 10 or part_number == 55:
    unit_cost = 1.00
elif part_number == 99:
    unit_cost = 2.00
elif part_number == 80 or part_number == 70:
    unit_cost = 3.00
else:
    unit_cost = 5.00

#Calculate total cost
total_cost = unit_cost * quantity

#Display results
print("Part number:", part_number)
print("Cost per unit: $", unit_cost)
print("Total cost: $", total_cost)