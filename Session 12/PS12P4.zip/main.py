# Function to display player names and batting averages
def display_players(players, averages):
    for i in range(len(players)):
        print(f"{players[i]} - Batting Average: {averages[i]}")

# Function to search for player name and display batting average
def search_player(players, averages, name):
    found = False
    for i in range(len(players)):
        if players[i] == name:
            print(f"{name} - Batting Average: {averages[i]}")
            found = True
            break
    if not found:
        print("Name not found")

# Main program
players = []
averages = []

with open("player_data.txt", "r") as file:
    for line in file:
        player, average = line.strip().split(",")
        players.append(player)
        averages.append(float(average))

display_players(players, averages)

while True:
    name = input("\nEnter player's last name to search (or 'quit' to exit): ")
    if name.lower() == "quit":
        break
    search_player(players, averages, name)
