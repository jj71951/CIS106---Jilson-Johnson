# Function to display last names
def display_names(names):
    for name in names:
        print(name)

# Function to display last names in reverse order
def display_names_reverse(names):
    for name in reversed(names):
        print(name)

# Main program
last_names = [
    "Smith", "Johnson", "Williams", "Brown", "Jones", 
    "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"
]
print("Displaying last names:")
display_names(last_names)

print("\nDisplaying last names in reverse order:")
display_names_reverse(last_names)
