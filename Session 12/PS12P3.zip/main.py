# Function to display highest and lowest scores
def display_high_low(names, scores):
    high_var = 0
    high_index = 0
    low_var = 999
    low_index = 0

    for i in range(len(scores)):
        if scores[i] > high_var:
            high_var = scores[i]
            high_index = i
        if scores[i] < low_var:
            low_var = scores[i]
            low_index = i

    print(f"Highest Score: {names[high_index]} - {high_var}")
    print(f"Lowest Score: {names[low_index]} - {low_var}")

# Main program
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]
exam_scores = [90, 85, 78, 92, 88, 76, 85, 90, 82, 87]

display_high_low(last_names, exam_scores)
