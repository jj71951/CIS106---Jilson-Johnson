# Function to search for player name and display batting average with message
def search_player_with_message(players, averages, name):
    found = False
    for i in range(len(players)):
        if players[i] == name:
            print(f"{name} - Batting Average: {averages[i]}")
            found = True
            break
    if not found:
        print("Name not found")

# Main program
players = []
averages = []

with open("player_data.txt", "r") as file:
    for line in file:
        player, average = line.strip().split(",")
        players.append(player)
        averages.append(float(average))

while True:
    name = input("\nEnter player's last name to search (or 'quit' to exit): ")
    if name.lower() == "quit":
        break
    search_player_with_message(players, averages, name)