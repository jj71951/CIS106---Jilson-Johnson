# Function to display last names and exam scores
def display_names_and_scores(names, scores):
    for i in range(len(names)):
        print(f"{names[i]} - Exam Score: {scores[i]}")

# Function to display last names and exam scores in reverse order
def display_names_and_scores_reverse(names, scores):
    for i in range(len(names) - 1, -1, -1):
        print(f"{names[i]} - Exam Score: {scores[i]}")

# Main program
last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]
exam_scores = [90, 85, 78, 92, 88, 76, 85, 90, 82, 87]

print("Displaying last names and exam scores:")
display_names_and_scores(last_names, exam_scores)

print("\nDisplaying last names and exam scores in reverse order:")
display_names_and_scores_reverse(last_names, exam_scores)
