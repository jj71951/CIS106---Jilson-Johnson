#Initialize Counter
counter = 1

#Loop to display odd numbers from 1 to 25

while counter <= 25:
  #Check if the current number is odd
  if counter % 2 != 0:
      print(counter)
  #Increment the counter
  counter += 1