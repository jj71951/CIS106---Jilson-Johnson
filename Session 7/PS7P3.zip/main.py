#Initialize loop control variable 
response = input("Do you want to continue? Enter 'Yes' or any other key to stop: ")

#Initialoze variables to count number of students
student_count = 0

#Check is user wants to continue
while response.lower == "Yes":
  #Promot user for last name and exam scores
  last_name = input("Enter your last name: ")
  exam1_score = float(input("Enter your first exam score: "))
  exam2_score = float(input("Enter your second exam score: "))

  #Calculate average exam score
  average_score = (exam1_score + exam2_score) / 2

  #Display student last name and average exam score
  print("Last Name: ", last_name)
  print("Average Exam Score: ", average_score)

  #Increment student count
  student_count += 1

  #Prompt user again to continue or stop
  response = input("Do you want to continue? Enter 'Yes' or any other key to stop: ")

#Display number of students who entered data
print("Number of students:", student_count)