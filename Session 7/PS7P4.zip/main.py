#Initialize loop control variable
response = input("Do you want to continue? Enter 'Yes' or any other key to stop: ")

#Initiatize accumulator variable
total_gross_pay = 0
employee_count = 0

#Check if user wants to continue
while response.lower() == 'yes':
  #Prompt user for employee details
  last_name = input("Enter employee's last name: ")
  hours_worked = float(input("Enter hours worked: "))
  rate_of_pay = float(input("Enter rate of pay: "))

  #Calculate gross pay
  if hours_worked > 40:
      gross_pay = (40 * rate_of_pay) + ((hours_worked - 40) * 1.5 * rate_of_pay)
  else:
    gross_pay = hours_worked * rate_of_pay

  #Display employee details and gross pay
  print("Last Name:", last_name)
  print("Gross Pay: ", gross_pay)

  #Add gross pay to total gross pay and increment employee count
  total_gross_pay += gross_pay
  employee_count += 1  

  #Prompt user again to continue or stop
  response = input("Do you want to continue? Enter 'Yes' or any other key to stop: ")

#Display total gross pay, count of employees, and average gross pay
print("Total Gross Pay: ", total_gross_pay)
print("Number of Employees: ", employee_count)
if employee_count != 0:
  print("Average Gross Pay: ", total_gross_pay / employee_count)
else:
  print("No employees entered data.")