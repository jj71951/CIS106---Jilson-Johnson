#Initialize loop control variable
response = input("Do you want to continue? Enter 'Yes' or any other key to stop: ")

#Intialize variable to store total discount
total_discount = 0

#Check if user wants to continue
while response.lower() == "Yes":
  # Prompt user for quantity and price of an item
  quantity = int(input("Enter the quantity of the item: "))
  price = float(input("Enter the price of the item: "))

  #Compute extended price
  extended_price = quantity * price

  # Apply discount based on extended price using ternary operator
  discount_percent = 0.25 if extended_price > 10000.0 else 0.10

  # Compute discount amount and total
  discount_amount = extended_price * discount_percent
  total = extended_price - discount_amount

  #Display extended price, discount amount, and total\
  print("Extended price: $", extended_price)
  print("Discount amount: $", discount_amount)
  print("Total: $", total)

  #Add discount amount to total_discount
  total_discount += discount_amount

  #Prompt user again to continue or stop
  response = input("Do you want to continue? Enter 'Yes' or any other key to stop: ")


#Display total discount
print("Total discount: $", total_discount)
    