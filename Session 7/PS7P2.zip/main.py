#Initialize loop control variable
response = input("Do you want to continue? (Enter 'Yes' or any other key to stop): ")

#Check if user wants to continue
while response.lower == "Yes":
  #Input start value, stop value, and increment value
  start_value = int(input("Enter the start value: "))
  stop_value = int(input("Enter the stop value: "))
  increment_value = int(input("Enter the increment value: "))

  #Display numbers from start value to stop value with increment value
  current_value = start_value
  while current_value <= stop_value:
    print(current_value)
    current_value += increment_value

  #Prompt user again to continue or stop
  response = input("Do you want to continue? (Enter 'Yes' or any other key to stop): ")