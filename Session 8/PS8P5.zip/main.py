# Initialize variables
total_tuition_owed = 0
student_count = 0

# Open and read the student data file
with open("student_data.txt", "r") as file:
    # Loop through each line of the file
    for line in file:
        # Extract student last name, district code, and credits taken from file
        last_name = line.strip()
        district_code = file.readline().strip()
        credits_taken = int(file.readline().strip())

        # Determine cost per credit based on district code
        cost_per_credit = 250.00 if district_code == "I" else 500.00

        # Compute tuition owed
        tuition_owed = credits_taken * cost_per_credit

        # Display student last name, credits taken, and tuition owed
        print("Student Last Name:", last_name)
        print("Credits Taken:", credits_taken)
        print("Tuition Owed:", tuition_owed)
        print()

        # Update total tuition owed and student count
        total_tuition_owed += tuition_owed
        student_count += 1

# Display total tuition owed and number of students
print("Total Tuition Owed:", total_tuition_owed)
print("Number of Students:", student_count)
