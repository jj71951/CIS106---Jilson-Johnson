# Initialize variables
total_interest_earned = 0

# Loop to allow user to enter principle amount and interest rate repeatedly
for year in range(1, 6):
      # Input principle amount and interest rate
      principle = float(input("Enter principle amount: "))
      interest_rate = float(input("Enter interest rate (in decimal): "))

      # Compute annual interest
      annual_interest = principle * interest_rate

      # Compute ending balance
      ending_balance = principle + annual_interest

      # Display year, beginning balance, and ending balance
      print(f"Year {year}:")
      print(f"Beginning Balance: ${principle:.2f}")
      print(f"Ending Balance: ${ending_balance:.2f}")

      # Update total interest earned
      total_interest_earned += annual_interest

      # Update principle for next year
      principle = ending_balance
# Display total interest earned
print(f"Total Interest Earned: ${total_interest_earned:.2f}")
