# Initialize variables
total_bonus_paid = 0

# Open and read the employee data file
with open("employee_data.txt", "r") as file:
    lines = file.readlines()

    # Loop through each line of the file
    for i in range(0, len(lines), 2):
        # Extract employee last name and salary from file
        last_name = lines[i].strip()
        salary = float(lines[i+1])

        # Determine bonus rate based on salary
        if salary >= 100000.00:
            bonus_rate = 0.20
        elif salary == 50000.00:
            bonus_rate = 0.15
        else:
            bonus_rate = 0.10

        # Compute bonus
        bonus = salary * bonus_rate

        # Display employee last name, salary, and bonus
        print("Employee Last Name:", last_name)
        print("Salary:", salary)
        print("Bonus:", bonus)
        print()

        # Update total bonus paid
        total_bonus_paid += bonus

# Display total bonus paid out
print("Total Bonus Paid Out:", total_bonus_paid)
