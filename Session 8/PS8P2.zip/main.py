# Initialize variables for the first two numbers in the sequence
a, b = 1, 1

# Display the first two numbers
print(a)
print(b)

# Loop to compute and display the next 18 numbers in the sequence
for _ in range(18):
    # Compute the next number in the sequence
    c = a + b
    # Display the next number
    print(c)
    # Update variables for the next iteration
    a, b = b, c
