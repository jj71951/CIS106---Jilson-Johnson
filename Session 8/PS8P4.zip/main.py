# Initialize variables
total_extended_price = 0
order_count = 0

# Open and read the item data file
with open("item_data.txt", "r") as file:
    # Loop through each line of the file
    for line in file:
        # Extract item, quantity, and price from file
        item = line.strip()
        quantity = int(file.readline().strip())
        price = float(file.readline().strip())

        # Compute extended price
        extended_price = quantity * price

        # Display item, quantity, price, and extended price
        print("Item:", item)
        print("Quantity:", quantity)
        print("Price:", price)
        print("Extended Price:", extended_price)
        print()

        # Update total extended price and order count
        total_extended_price += extended_price
        order_count += 1

# Display total extended price, order count, and average order
print("Total Extended Price:", total_extended_price)
print("Number of Orders:", order_count)
print("Average Order:", total_extended_price / order_count)
